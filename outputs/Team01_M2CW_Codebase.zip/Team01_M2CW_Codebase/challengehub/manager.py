"""Application layer coordinator for ChallengeHub."""
from __future__ import annotations
from datetime import date, datetime
from pathlib import Path
from uuid import uuid4
from typing import Optional, List, Dict, Any, Union

from . import models, storage
from .models import Participant, Challenge, Enrollment, ActivityRecord
from .strategies import ProgressStrategy, resolve_strategy


class ChallengeManager:
    """Coordinates use-case workflows, invariants, and storage dispatch."""

    def __init__(self, data_dir: Optional[Path] = None) -> None:
        raw_dir = data_dir or (Path(__file__).resolve().parent.parent / "data")
        self.data_dir = Path(raw_dir)

        # Baseline storage file bindings
        p_path = self.data_dir / "participants.json"
        c_path = self.data_dir / "challenges.json"
        e_path = self.data_dir / "enrollments.json"
        a_path = self.data_dir / "activities.csv"

        self.participants: List[Participant] = storage.load_participants(p_path)
        self.challenges: List[Challenge] = storage.load_challenges(c_path)
        self.enrollments: List[Enrollment] = storage.load_enrollments(e_path)
        self.activities: List[ActivityRecord] = storage.load_activities(a_path)

    def reload(self) -> None:
        """Reloads in-memory collections from persistent storage files."""
        self.participants = storage.load_participants(self.data_dir / "participants.json")
        self.challenges = storage.load_challenges(self.data_dir / "challenges.json")
        self.enrollments = storage.load_enrollments(self.data_dir / "enrollments.json")
        self.activities = storage.load_activities(self.data_dir / "activities.csv")

    def _participant(self, participant_id: str) -> Optional[Participant]:
        return next((p for p in self.participants if p.participant_id == participant_id), None)

    def _challenge(self, challenge_id: str) -> Optional[Challenge]:
        return next((c for c in self.challenges if c.challenge_id == challenge_id), None)

    def record_activity(
        self,
        participant_id: str,
        challenge_id: str,
        activity_type: str,
        amount: float,
        activity_date: Union[str, date],
        note: str = ""
    ) -> ActivityRecord:
        """Executes the Record Activity operational contract.

        Guarantees:
        - Resolves participant, challenge, and enrollment evidence before mutation.
        - Validates amount, activity type, and dates before state change.
        - On invalid input, raises ValueError and performs zero storage mutation.
        - Creates exactly one ActivityRecord and persists it once.
        """
        # Step 1: Precondition - Resolve participant evidence
        if self._participant(participant_id) is None:
            raise ValueError("Unknown participant")

        # Step 2: Precondition - Resolve challenge evidence
        challenge = self._challenge(challenge_id)
        if challenge is None:
            raise ValueError("Unknown challenge")

        # Step 3: Precondition - Resolve enrollment evidence
        if not any(x.participant_id == participant_id and x.challenge_id == challenge_id for x in self.enrollments):
            raise ValueError("Participant is not enrolled")

        # Step 4: Validate amount (> 0)
        if float(amount) <= 0:
            raise ValueError("Amount must be positive")

        # Step 5: Validate activity type matches challenge
        if challenge.activity_type.lower() != activity_type.lower():
            raise ValueError("Activity type does not match challenge")

        # Normalize date to date object for model/storage and string for boundary comparison
        if isinstance(activity_date, date):
            act_date_obj = activity_date
            act_d_str = activity_date.isoformat()
        else:
            act_d_str = str(activity_date).strip()
            act_date_obj = datetime.strptime(act_d_str, "%Y-%m-%d").date()

        start_d_str = challenge.start_date.isoformat() if isinstance(challenge.start_date, date) else str(challenge.start_date).strip()
        end_d_str = challenge.end_date.isoformat() if isinstance(challenge.end_date, date) else str(challenge.end_date).strip()

        # Step 6: Validate activity date is within challenge period
        if act_d_str < start_d_str or act_d_str > end_d_str:
            raise ValueError("Activity date is outside the challenge period")

        # Post-validation: Create exactly one accepted ActivityRecord
        record = ActivityRecord(
            record_id=f"AR-{uuid4().hex[:8].upper()}",
            participant_id=participant_id,
            challenge_id=challenge_id,
            activity_type=activity_type,
            amount=float(amount),
            activity_date=act_date_obj,
            note=note.strip()
        )

        # Mutate in-memory collection and persist exactly once
        self.activities.append(record)
        storage.save_activities(self.data_dir / "activities.csv", self.activities)
        print(f"Activity recorded for {participant_id}: {record.amount:g} {challenge.goal_unit}")
        return record

    def progress(
        self,
        participant_id: str,
        challenge_id: str,
        strategy: Optional[ProgressStrategy] = None
    ) -> Dict[str, Any]:
        """Dynamic derived query computing participant progress from accepted records."""
        challenge = self._challenge(challenge_id)
        if challenge is None:
            raise ValueError("Unknown challenge")
        if not any(x.participant_id == participant_id and x.challenge_id == challenge_id for x in self.enrollments):
            raise ValueError("Participant is not enrolled")

        # Filter accepted activity records
        matching_records = [
            r for r in self.activities
            if r.participant_id == participant_id and r.challenge_id == challenge_id
        ]

        # Calculate dynamic progress via pure domain strategy
        evaluator = strategy or resolve_strategy(challenge.goal_unit)
        current_value = evaluator.calculate(matching_records, challenge.goal_target)

        target = challenge.goal_target
        pct = min(100.0, round((current_value / target) * 100.0, 2)) if target > 0 else 0.0
        status = "Completed" if current_value >= target else "In progress"

        return {
            "participant": participant_id,
            "challenge": challenge_id,
            "total": float(current_value),
            "goal": float(target),
            "pct": pct,
            "status": status,
        }
