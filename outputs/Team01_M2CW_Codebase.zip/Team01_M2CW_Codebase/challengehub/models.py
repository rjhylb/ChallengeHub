"""Core domain models for ChallengeHub."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from typing import Optional, Union


@dataclass(frozen=True)
class Participant:
    participant_id: str
    name: str
    email: str


@dataclass(frozen=True)
class Challenge:
    challenge_id: str
    name: str
    category: str
    activity_type: str
    goal_unit: str
    goal_target: float
    start_date: Union[str, date]
    end_date: Union[str, date]


@dataclass(frozen=True)
class Enrollment:
    participant_id: str
    challenge_id: str
    joined_on: Union[str, date]


@dataclass(frozen=True)
class ActivityRecord:
    record_id: str
    participant_id: str
    challenge_id: str
    activity_type: str
    amount: float
    activity_date: Union[date, str]
    note: str = ""


@dataclass(frozen=True)
class ProgressSummary:
    participant_id: str
    challenge_id: str
    current_value: float
    target_value: float
    progress_pct: float
    status: str
