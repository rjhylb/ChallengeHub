"""Domain progress evaluation strategies for ChallengeHub.

Pure domain core: contains zero outward imports to manager, storage, or presentation.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Sequence
from .models import ActivityRecord


class ProgressStrategy(ABC):
    """Abstract base strategy for dynamic challenge progress evaluation."""

    @abstractmethod
    def calculate(self, records: Sequence[ActivityRecord], goal_target: float) -> float:
        """Calculate the total accumulated progress toward the goal target."""
        raise NotImplementedError


class AmountProgressStrategy(ProgressStrategy):
    """Accumulates cumulative activity amounts (e.g., miles, kilometers, pages)."""

    def calculate(self, records: Sequence[ActivityRecord], goal_target: float) -> float:
        return float(sum(r.amount for r in records))


class CountProgressStrategy(ProgressStrategy):
    """Counts qualifying activity event entries (e.g., sessions, check-ins)."""

    def calculate(self, records: Sequence[ActivityRecord], goal_target: float) -> float:
        return float(len(records))


def resolve_strategy(challenge_goal_unit: str | None) -> ProgressStrategy:
    """Strategy resolution helper mapping challenge goal units/types to concrete strategies."""
    normalized = (challenge_goal_unit or "").strip().lower()
    if normalized in {"session", "sessions", "check-in", "check-ins", "count"}:
        return CountProgressStrategy()
    return AmountProgressStrategy()
